<!DOCTYPE html>
<html>

<head>
    <title>Dashboard Dokumentasi Kegiatan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h2 class="mt-2">Dashboard Dokumentasi Kegiatan</h2>
        <a class="btn btn-primary mt-2 mb-2">Tambah Foto Kegiatan</a>
        <table class="table table-bordered">
            <tr>
                <th>ID</th>
                <th>Foto Kegiatan</th>
                <th>Keterangan</th>
                <th>Timestamps</th>
                <th>Aksi</th>
            </tr>
            <?php $__currentLoopData = $fotodokumentasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokumentasifoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($dokumentasifoto->id); ?></td>
                <td><img src="/images/<?php echo e($dokumentasifoto->fotokegiatan); ?>" width="100px"></td>
                <td><?php echo e($dokumentasifoto->keterangan); ?></td>
                <td><?php echo e($dokumentasifoto->created_at); ?> / <?php echo e($dokumentasifoto->updated_at); ?></td>
                <td>
                    <a href="<?php echo e(route('fotodokumentasi.edit', $dokumentasifoto->id)); ?>" class="btn btn-primary">Edit</a>
                    <form action="<?php echo e(route('fotodokumentasi.destroy', $dokumentasifoto->id)); ?>" method="POST" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel-projects\bbay\resources\views///dashboard/dashboarddokumentasi.blade.php ENDPATH**/ ?>