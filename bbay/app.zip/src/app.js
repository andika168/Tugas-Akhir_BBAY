// src/app.js
alert('hello world');